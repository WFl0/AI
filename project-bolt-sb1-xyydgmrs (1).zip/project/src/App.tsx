import React from 'react'
import { motion } from 'framer-motion'
import { Layout } from './components/Layout'
import { Header } from './components/Header'
import { ChatInterface } from './components/ChatInterface'

function App() {
  return (
    <Layout>
      <Header />
      <main className="flex-1 p-4">
        <div className="max-w-4xl mx-auto h-full">
          <ChatInterface />
        </div>
      </main>
    </Layout>
  )
}

export default App