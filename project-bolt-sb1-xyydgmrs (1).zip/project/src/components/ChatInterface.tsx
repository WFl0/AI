import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Paperclip, Image, FileText, Video, Bot, User, X, Sparkles, Zap } from 'lucide-react'
import { sendMessageToOpenAI, processImageWithAI } from '../lib/openai'

interface Message {
  id: string
  content: string
  sender: 'user' | 'ai'
  timestamp: Date
  files?: File[]
  imagePreview?: string
}

export const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'أهلاً وسهلاً! أنا مساعدك الذكي باللهجة السعودية. كيف أقدر أساعدك اليوم؟ تقدر ترسل لي صور وملفات وأحللها لك! 🚀✨',
      sender: 'ai',
      timestamp: new Date()
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [loading, setLoading] = useState(false)
  const [imagePreview, setImagePreview] = useState<string>('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)
      setSelectedFiles(prev => [...prev, ...files])
      
      files.forEach(file => {
        if (file.type.startsWith('image/')) {
          const reader = new FileReader()
          reader.onload = (e) => {
            setImagePreview(e.target?.result as string)
          }
          reader.readAsDataURL(file)
        }
      })
    }
  }

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index))
    if (selectedFiles.length === 1) {
      setImagePreview('')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputMessage.trim() && selectedFiles.length === 0) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage || 'تحليل الملفات المرفقة',
      sender: 'user',
      timestamp: new Date(),
      files: selectedFiles.length > 0 ? selectedFiles : undefined,
      imagePreview: imagePreview || undefined
    }

    setMessages(prev => [...prev, userMessage])
    const currentMessage = inputMessage
    const currentFiles = [...selectedFiles]
    
    setInputMessage('')
    setSelectedFiles([])
    setImagePreview('')
    setLoading(true)

    try {
      let aiResponse = ''

      if (currentFiles.some(file => file.type.startsWith('image/'))) {
        const imageFile = currentFiles.find(file => file.type.startsWith('image/'))
        if (imageFile) {
          aiResponse = await processImageWithAI(imageFile, currentMessage) as string
        }
      } else {
        aiResponse = await sendMessageToOpenAI(currentMessage, currentFiles)
      }
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date()
      }

      setMessages(prev => [...prev, aiMessage])
    } catch (error) {
      console.error('AI Error:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: 'عذراً، حدث خطأ في معالجة طلبك. تأكد من اتصالك بالإنترنت وحاول مرة أخرى. 🔄',
        sender: 'ai',
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    }

    setLoading(false)
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image className="h-4 w-4" />
    if (file.type.startsWith('video/')) return <Video className="h-4 w-4" />
    return <FileText className="h-4 w-4" />
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="flex flex-col h-full bg-gray-800/50 backdrop-blur-xl rounded-3xl shadow-2xl overflow-hidden border border-gray-700/50 relative"
    >
      {/* Chat Header with Glow Effect */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="bg-gradient-to-r from-gray-800/80 to-gray-900/80 backdrop-blur-xl p-4 border-b border-gray-700/50 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10" />
        <div className="relative z-10 flex items-center justify-center space-x-3 space-x-reverse">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="h-6 w-6 text-yellow-400" />
          </motion.div>
          <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            محادثة ذكية
          </h3>
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          >
            <Zap className="h-6 w-6 text-cyan-400" />
          </motion.div>
        </div>
      </motion.div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-gradient-to-b from-gray-900/20 to-gray-800/20 relative">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                             radial-gradient(circle at 75% 75%, rgba(147, 51, 234, 0.1) 0%, transparent 50%)`
          }} />
        </div>

        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -50, scale: 0.9 }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.1,
                type: "spring",
                stiffness: 100
              }}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'} relative z-10`}
            >
              <div className={`flex items-start space-x-4 space-x-reverse max-w-[85%] group`}>
                {/* Avatar */}
                <motion.div
                  whileHover={{ scale: 1.2, rotate: 360 }}
                  whileTap={{ scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-2xl relative overflow-hidden ${
                    message.sender === 'user' 
                      ? 'bg-gradient-to-br from-blue-600 via-blue-700 to-purple-700' 
                      : 'bg-gradient-to-br from-purple-600 via-indigo-600 to-pink-600'
                  }`}
                >
                  {/* Avatar Glow */}
                  <div className={`absolute inset-0 ${
                    message.sender === 'user' 
                      ? 'bg-gradient-to-br from-blue-400/20 to-purple-400/20' 
                      : 'bg-gradient-to-br from-purple-400/20 to-pink-400/20'
                  } blur-xl`} />
                  
                  <div className="relative z-10">
                    {message.sender === 'user' ? (
                      <User className="h-6 w-6 text-white" />
                    ) : (
                      <motion.div
                        animate={{ rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <Bot className="h-6 w-6 text-white" />
                      </motion.div>
                    )}
                  </div>
                </motion.div>
                
                {/* Message Bubble */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className={`p-6 rounded-3xl shadow-2xl backdrop-blur-xl relative overflow-hidden ${
                    message.sender === 'user'
                      ? 'bg-gradient-to-br from-blue-600/90 via-blue-700/90 to-purple-700/90 text-white border border-blue-500/30'
                      : 'bg-gradient-to-br from-gray-800/90 via-gray-700/90 to-gray-800/90 text-gray-100 border border-gray-600/30'
                  }`}
                >
                  {/* Message Glow Effect */}
                  <div className={`absolute inset-0 ${
                    message.sender === 'user'
                      ? 'bg-gradient-to-br from-blue-400/10 to-purple-400/10'
                      : 'bg-gradient-to-br from-purple-400/5 to-pink-400/5'
                  } blur-xl`} />
                  
                  <div className="relative z-10">
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.2, duration: 0.8 }}
                      className="text-sm leading-relaxed whitespace-pre-wrap font-medium"
                    >
                      {message.content}
                    </motion.p>
                    
                    {/* Image Preview */}
                    {message.imagePreview && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3, duration: 0.5 }}
                        className="mt-4"
                      >
                        <img 
                          src={message.imagePreview} 
                          alt="صورة مرفقة" 
                          className="max-w-xs rounded-2xl shadow-xl border border-gray-600/30"
                        />
                      </motion.div>
                    )}
                    
                    {/* File Attachments */}
                    {message.files && message.files.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4, duration: 0.5 }}
                        className="mt-4 space-y-2"
                      >
                        {message.files.map((file, index) => (
                          <div key={index} className="flex items-center space-x-3 space-x-reverse text-xs opacity-80 bg-black/20 rounded-xl p-3 backdrop-blur-sm">
                            {getFileIcon(file)}
                            <span className="truncate font-medium">{file.name}</span>
                            <span className="text-xs opacity-60">({(file.size / 1024).toFixed(1)} KB)</span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                    
                    {/* Timestamp */}
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.5, duration: 0.5 }}
                      className="text-xs opacity-60 mt-4 font-light"
                    >
                      {message.timestamp.toLocaleTimeString('ar-SA', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </motion.p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Loading Animation */}
        {loading && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="flex justify-start"
          >
            <div className="flex items-start space-x-4 space-x-reverse">
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                  rotate: [0, 360]
                }}
                transition={{ 
                  scale: { duration: 2, repeat: Infinity },
                  rotate: { duration: 3, repeat: Infinity, ease: "linear" }
                }}
                className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 via-indigo-600 to-pink-600 flex items-center justify-center shadow-2xl"
              >
                <Bot className="h-6 w-6 text-white" />
              </motion.div>
              <div className="bg-gradient-to-br from-gray-800/90 to-gray-700/90 backdrop-blur-xl border border-gray-600/30 p-6 rounded-3xl shadow-2xl">
                <div className="flex space-x-2 space-x-reverse">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      animate={{
                        scale: [1, 1.5, 1],
                        opacity: [0.5, 1, 0.5]
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        delay: i * 0.2
                      }}
                      className="w-3 h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                    />
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-3 font-medium">جاري التفكير...</p>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* File Preview */}
      <AnimatePresence>
        {selectedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-gray-700/50 p-4 bg-gray-800/50 backdrop-blur-xl"
          >
            <div className="flex flex-wrap gap-3">
              {selectedFiles.map((file, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8, x: -50 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.8, x: 50 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative flex items-center space-x-3 space-x-reverse bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-sm border border-blue-500/30 text-blue-300 px-4 py-3 rounded-2xl shadow-lg"
                >
                  {getFileIcon(file)}
                  <span className="text-sm truncate max-w-32 font-medium">{file.name}</span>
                  <motion.button
                    whileHover={{ scale: 1.2, rotate: 90 }}
                    whileTap={{ scale: 0.8 }}
                    onClick={() => removeFile(index)}
                    className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs transition-colors shadow-lg"
                  >
                    <X className="h-3 w-3" />
                  </motion.button>
                </motion.div>
              ))}
            </div>
            
            {imagePreview && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-4"
              >
                <img 
                  src={imagePreview} 
                  alt="معاينة الصورة" 
                  className="max-w-40 h-24 object-cover rounded-2xl shadow-xl border border-gray-600/30"
                />
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input Area */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="border-t border-gray-700/50 p-6 bg-gradient-to-r from-gray-800/80 to-gray-900/80 backdrop-blur-xl relative overflow-hidden"
      >
        {/* Input Background Glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 via-purple-600/5 to-pink-600/5" />
        
        <form onSubmit={handleSubmit} className="flex items-end space-x-4 space-x-reverse relative z-10">
          <div className="flex-1">
            <div className="flex items-center space-x-4 space-x-reverse bg-gray-700/50 backdrop-blur-xl rounded-3xl px-6 py-4 border border-gray-600/30 focus-within:border-blue-500/50 focus-within:shadow-lg focus-within:shadow-blue-500/20 transition-all duration-300">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="اكتب رسالتك هنا أو أرفق صورة للتحليل... ✨"
                className="flex-1 bg-transparent outline-none text-gray-100 placeholder-gray-400 font-medium"
                disabled={loading}
              />
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
                accept="image/*,video/*,.pdf,.doc,.docx,.txt"
              />
              
              <motion.button
                whileHover={{ scale: 1.2, rotate: 15 }}
                whileTap={{ scale: 0.9 }}
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-gray-400 hover:text-blue-400 transition-colors p-2 rounded-xl hover:bg-blue-500/10"
                disabled={loading}
              >
                <Paperclip className="h-6 w-6" />
              </motion.button>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.1, boxShadow: "0 0 30px rgba(59, 130, 246, 0.5)" }}
            whileTap={{ scale: 0.9 }}
            type="submit"
            disabled={loading || (!inputMessage.trim() && selectedFiles.length === 0)}
            className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-500 hover:via-purple-500 hover:to-pink-500 text-white p-4 rounded-3xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl relative overflow-hidden"
          >
            {/* Button Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-400/20 blur-xl" />
            
            <div className="relative z-10">
              {loading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-6 h-6"
                >
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full" />
                </motion.div>
              ) : (
                <motion.div
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <Send className="h-6 w-6" />
                </motion.div>
              )}
            </div>
          </motion.button>
        </form>
      </motion.div>
    </motion.div>
  )
}