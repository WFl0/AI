import React from 'react'
import { motion } from 'framer-motion'
import { Brain, Sparkles, Zap } from 'lucide-react'

export const Header: React.FC = () => {
  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="bg-gray-900/80 backdrop-blur-xl border-b border-gray-700/50 shadow-2xl relative overflow-hidden"
    >
      {/* Header Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 via-purple-600/5 to-pink-600/5" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex items-center justify-center h-24">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center space-x-6 space-x-reverse group cursor-pointer"
          >
            {/* Animated Logo */}
            <motion.div
              animate={{
                boxShadow: [
                  "0 0 20px rgba(59, 130, 246, 0.5)",
                  "0 0 30px rgba(147, 51, 234, 0.5)",
                  "0 0 20px rgba(59, 130, 246, 0.5)"
                ]
              }}
              transition={{ duration: 3, repeat: Infinity }}
              className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 p-4 rounded-3xl shadow-2xl"
            >
              <Brain className="h-12 w-12 text-white" />
              
              {/* Floating Icons Around Logo */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="absolute -top-2 -right-2"
              >
                <Sparkles className="h-4 w-4 text-yellow-400" />
              </motion.div>
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                className="absolute -bottom-2 -left-2"
              >
                <Zap className="h-4 w-4 text-cyan-400" />
              </motion.div>
            </motion.div>
            
            {/* Title Section */}
            <div className="text-center">
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent group-hover:from-blue-300 group-hover:via-purple-300 group-hover:to-pink-300 transition-all duration-500"
              >
                الذكاء الاصطناعي
              </motion.h1>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5, duration: 0.6 }}
                className="flex items-center justify-center space-x-3 space-x-reverse mt-2"
              >
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="h-5 w-5 text-amber-400" />
                </motion.div>
                
                <motion.p
                  whileHover={{ scale: 1.05 }}
                  className="text-lg text-gray-300 font-medium bg-gradient-to-r from-gray-300 to-gray-100 bg-clip-text text-transparent"
                >
                  مساعدك الذكي باللهجة السعودية
                </motion.p>
                
                <motion.div
                  animate={{ rotate: [360, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="h-5 w-5 text-amber-400" />
                </motion.div>
              </motion.div>
              
              {/* Subtitle with typing effect */}
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ delay: 1, duration: 2 }}
                className="mt-2 overflow-hidden"
              >
                <p className="text-sm text-gray-400 font-light">
                  تم تطويري بحب وجهد من أحمد أبو هليل 💙
                </p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Bottom Glow Line */}
      <motion.div
        animate={{
          scaleX: [0, 1, 0],
          opacity: [0, 1, 0]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-64 h-0.5 bg-gradient-to-r from-transparent via-blue-500 to-transparent"
      />
    </motion.header>
  )
}