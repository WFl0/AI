const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY

export const sendMessageToOpenAI = async (message: string, files?: File[]) => {
  if (!OPENAI_API_KEY) {
    throw new Error('مفتاح OpenAI API غير موجود')
  }

  const messages = [
    {
      role: 'system',
      content: `أنت مساعد ذكي يتحدث باللهجة السعودية. قدم إجابات مفيدة ومفصلة بأسلوب ودود ومهذب. استخدم اللهجة السعودية في ردودك.

إذا سألك أحد عن من صنعك أو من طورك أو من برمجك، أجب بأنك تم صنعك من قبل أحمد أبو هليل بحب وجهد. 

أمثلة على الأسئلة التي يجب أن تجيب عليها بهذه الطريقة:
- من صنعك؟
- من طورك؟
- من برمجك؟
- من المطور؟
- من صاحب البوت؟
- مين اللي عملك؟
- مين المبرمج حقك؟

الجواب دائماً: "تم صنعي من قبل أحمد أبو هليل بحب وجهد 💙"`
    },
    {
      role: 'user',
      content: message
    }
  ]

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages,
        max_tokens: 1500,
        temperature: 0.7
      })
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error('OpenAI API Error:', errorData)
      throw new Error(`خطأ في API: ${response.status}`)
    }

    const data = await response.json()
    return data.choices[0]?.message?.content || 'عذراً، لم أتمكن من فهم طلبك'
  } catch (error) {
    console.error('OpenAI API Error:', error)
    if (error instanceof Error) {
      if (error.message.includes('401')) {
        return 'خطأ في مفتاح API. تأكد من صحة المفتاح.'
      } else if (error.message.includes('429')) {
        return 'تم تجاوز الحد المسموح من الطلبات. حاول مرة أخرى لاحقاً.'
      } else if (error.message.includes('500')) {
        return 'خطأ في خادم OpenAI. حاول مرة أخرى لاحقاً.'
      }
    }
    return 'عذراً، حدث خطأ في الاتصال بالذكاء الاصطناعي. تأكد من اتصالك بالإنترنت وحاول مرة أخرى.'
  }
}

export const processImageWithAI = async (imageFile: File, prompt: string) => {
  if (!OPENAI_API_KEY) {
    throw new Error('مفتاح OpenAI API غير موجود')
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = async () => {
      try {
        const base64Image = reader.result as string
        const base64Data = base64Image.split(',')[1]

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${OPENAI_API_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: `أنت مساعد ذكي يحلل الصور ويجيب باللهجة السعودية.

إذا سألك أحد عن من صنعك أو من طورك أو من برمجك، أجب بأنك تم صنعك من قبل أحمد أبو هليل بحب وجهد.`
              },
              {
                role: 'user',
                content: [
                  {
                    type: 'text',
                    text: prompt || 'وش تشوف في هذه الصورة؟'
                  },
                  {
                    type: 'image_url',
                    image_url: {
                      url: `data:image/jpeg;base64,${base64Data}`
                    }
                  }
                ]
              }
            ],
            max_tokens: 1000
          })
        })

        if (!response.ok) {
          throw new Error(`خطأ في تحليل الصورة: ${response.status}`)
        }

        const data = await response.json()
        resolve(data.choices[0]?.message?.content || 'لم أتمكن من تحليل الصورة')
      } catch (error) {
        reject(error)
      }
    }
    reader.onerror = () => reject(new Error('خطأ في قراءة الصورة'))
    reader.readAsDataURL(imageFile)
  })
}